﻿using Google.Apis.Storage.v1.Data;
using Google.Cloud.Storage.V1;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Alphtmost.Servicios
{
    public class GCSService
    {
        private readonly StorageClient _storageClient;
        private readonly string _bucketName;

        public GCSService(string bucketName, string credentialsFileName = "alphtmost-6e813193db21.json")
        {
            _bucketName = bucketName;
            var credentialsPath = Path.Combine(Directory.GetCurrentDirectory(), "Credenciales", credentialsFileName);
            if (!File.Exists(credentialsPath))
                throw new FileNotFoundException("El archivo de credenciales no se encuentra en la ruta especificada.", credentialsPath);

            _storageClient = StorageClient.Create(Google.Apis.Auth.OAuth2.GoogleCredential.FromFile(credentialsPath));
        }

        // Subir archivo al bucket y hacerlo público
        public async Task<string> UploadFileAsync(Stream fileStream, string objectName, string contentType)
        {
            // Subir el archivo
            var obj = await _storageClient.UploadObjectAsync(
                bucket: _bucketName,
                objectName: objectName,
                contentType: contentType,
                source: fileStream
            );
            // Retornar la URL pública
            return $"https://storage.googleapis.com/{_bucketName}/{objectName}";
        }

        // Eliminar archivo del bucket
        public async Task DeleteFileAsync(string objectName)
        {
            await _storageClient.DeleteObjectAsync(_bucketName, objectName);
        }
    }
}