﻿using Alphtmost.Modelos;
using Alphtmost.Servicios.Interfaz;
using AlphtmostAPI.Consumer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphtmost.Servicios.Implementacion
{
    public class AdministradorService : IAdministradorService
    {
        public async Task<Administrador> GetByEmailAsync(string email)
        {
            if (string.IsNullOrEmpty(email))
                throw new ArgumentNullException(nameof(email), "El correo no puede ser nulo o vacío.");

            try
            {
                return await Crud<Administrador>.GetByEmailAsync(email);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al obtener el usuario con el correo {email}: {ex.Message}");
                return null;
            }
        }

        public IEnumerable<Administrador> GetAllAdministradores()
        {
            try
            {
                var usuarios = Crud<Administrador>.GetAll(); // Obtener todos los usuarios
                return usuarios;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al obtener todos los usuarios: {ex.Message}");
                return new List<Administrador>();  // Devolver una lista vacía si ocurre un error
            }
        }

    }
}