﻿using Alphtmost.Modelos;
using Alphtmost.Servicios.Interfaz;
using AlphtmostAPI.Consumer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphtmost.Servicios.Implementacion
{
    public class ArtistaClienteService : IArtistaClienteService
    {
        private readonly ServicioDeVerificacionArtista _servicioDeVerificacionCorreo;

        //  servicio de verificación de correo
        public ArtistaClienteService(ServicioDeVerificacionArtista servicioDeVerificacionCorreo)
        {
            _servicioDeVerificacionCorreo = servicioDeVerificacionCorreo;
        }

        // obtener un artista por su correo de forma 
        public async Task<ArtistaCliente> GetByEmailAsync(string email)
        {
            if (string.IsNullOrEmpty(email))
                throw new ArgumentNullException(nameof(email), "El correo no puede ser nulo o vacío.");

            try
            {
                return await Crud<ArtistaCliente>.GetByEmailAsync(email);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al obtener el usuario con el correo {email}: {ex.Message}");
                return null;
            }
        }
        public async Task<bool> IsEmailRegisteredAsync(string email)
        {
            // verificación para comprobar si el correo está registrado en cualquiera de los tres servicios
            return await _servicioDeVerificacionCorreo.IsEmailRegisteredAsync(email);
        }

        // Método para obtener todos los artistas
        public IEnumerable<ArtistaCliente> GetAllArtistas()
        {
            try
            {
                var artistas = Crud<ArtistaCliente>.GetAll(); // Obtener todos los artistas
                return artistas;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al obtener todos los artistas: {ex.Message}");
                return new List<ArtistaCliente>();  // Devolver una lista vacía si ocurre un error
            }
        }

        // Método para crear un nuevo artista
        public ArtistaCliente CreateArtista(ArtistaCliente artista)
        {
            if (artista == null)
            {
                throw new ArgumentNullException(nameof(artista), "El artista no puede ser nulo");
            }

            try
            {

                var nuevoArtista = Crud<ArtistaCliente>.Create(artista);
                return nuevoArtista;
            }
            catch (Exception ex)
            {
                // Loguear el error
                Console.WriteLine($"Error al crear el artista con email {artista.Email}: {ex.Message}");
                return null; // Devolver null si la creación falla
            }
        }
    }
}
