﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Alphtmost.Servicios.Interfaz;

namespace Alphtmost.Servicios.Implementacion
{
    public class CancionComposite : ICancionComponent
    {
        private readonly List<ICancionComponent> _children = new();

        public void Add(ICancionComponent component)
        {
            _children.Add(component);
        }

        public async Task SubirAsync(IFileUploader uploader)
        {
            foreach (var child in _children)
            {
                await child.SubirAsync(uploader);
            }
        }
    }
}
