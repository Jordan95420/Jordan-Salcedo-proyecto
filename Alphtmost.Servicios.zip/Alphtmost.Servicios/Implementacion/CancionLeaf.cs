﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading.Tasks;
using Alphtmost.Servicios.Interfaz;

namespace Alphtmost.Servicios.Implementacion
{
    public class CancionLeaf : ICancionComponent
    {
        private readonly Stream _fileStream;
        private readonly string _fileName;
        private readonly string _contentType;

        public CancionLeaf(Stream fileStream, string fileName, string contentType)
        {
            _fileStream = fileStream;
            _fileName = fileName;
            _contentType = contentType;
        }

        public async Task SubirAsync(IFileUploader uploader)
        {
            await uploader.UploadFileAsync(_fileStream, _fileName, _contentType);
        }
    }
}
