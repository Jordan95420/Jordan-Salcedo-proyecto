﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading.Tasks;
using Alphtmost.Servicios.Interfaz;

namespace Alphtmost.Servicios.Implementacion
{
    public class GCSFileUploaderAdapter : IFileUploader
    {
        private readonly GCSService _gcsService;

        public GCSFileUploaderAdapter(GCSService gcsService)
        {
            _gcsService = gcsService;
        }

        public async Task<string> UploadFileAsync(Stream fileStream, string fileName, string contentType)
        {
            return await _gcsService.UploadFileAsync(fileStream, fileName, contentType);
        }
        public async Task DeleteFileAsync(string fileName) // <-- Implementa aquí
        {
            await _gcsService.DeleteFileAsync(fileName);
        }
    }
}
