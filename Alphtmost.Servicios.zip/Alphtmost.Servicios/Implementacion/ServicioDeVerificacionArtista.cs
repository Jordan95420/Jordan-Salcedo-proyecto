﻿using Alphtmost.Servicios.Interfaz;
using System;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace Alphtmost.Servicios.Implementacion
{
    public class ServicioDeVerificacionArtista
    {
        private readonly IServiceProvider _serviceProvider;

        public ServicioDeVerificacionArtista(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public async Task<bool> IsEmailRegisteredAsync(string email)
        {
            var usuarioClienteService = _serviceProvider.GetRequiredService<IUsuarioClienteService>();
            var adminService = _serviceProvider.GetRequiredService<IAdministradorService>();

            var existeUsuario = await usuarioClienteService.GetByEmailAsync(email);
            var existeAdmin = await adminService.GetByEmailAsync(email);

            return existeUsuario != null || existeAdmin != null;
        }
    }
}

