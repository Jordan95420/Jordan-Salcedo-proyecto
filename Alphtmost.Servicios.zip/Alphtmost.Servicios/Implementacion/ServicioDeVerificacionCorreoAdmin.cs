﻿using Alphtmost.Servicios.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphtmost.Servicios.Implementacion
{
    public class ServicioDeVerificacionCorreoAdmin
    {
        private readonly IArtistaClienteService _artistaClienteService;
        private readonly IUsuarioClienteService _usuarioCLienteService;

        // Constructor: Inyectamos los dos servicios para verificar el correo electronico cuando ingresa un nuevo cliente 
        public ServicioDeVerificacionCorreoAdmin(IArtistaClienteService artistaClienteService, IUsuarioClienteService usuarioCLienteService)
        {
            _artistaClienteService = artistaClienteService;
            _usuarioCLienteService = usuarioCLienteService;
        }

        // Método para verificar si el correo está registrado en alguno de los dos actores para evitar redundancias
        public async Task<bool> IsEmailRegisteredAsync(string email)
        {
            var existeArtista = await _artistaClienteService.GetByEmailAsync(email);
            var existeAdmin = await _usuarioCLienteService.GetByEmailAsync(email);

            return existeArtista != null || existeAdmin != null;
        }
    }
}
