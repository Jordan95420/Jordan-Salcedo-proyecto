﻿using Alphtmost.Servicios.Interfaz;
using System;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace Alphtmost.Servicios.Implementacion
{
    public class ServicioDeVerificacionCorreoCliente
    {
        private readonly IServiceProvider _serviceProvider;

        public ServicioDeVerificacionCorreoCliente(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public async Task<bool> IsEmailRegisteredAsync(string email)
        {
            var usuarioClienteService = _serviceProvider.GetRequiredService<IUsuarioClienteService>();
            var artistaService = _serviceProvider.GetRequiredService<IArtistaClienteService>();
            var adminService = _serviceProvider.GetRequiredService<IAdministradorService>();

            var existeUsuario = await usuarioClienteService.GetByEmailAsync(email);
            var existeArtista = await artistaService.GetByEmailAsync(email);
            var existeAdmin = await adminService.GetByEmailAsync(email);

            return existeUsuario != null || existeArtista != null || existeAdmin != null;
        }
    }
}
