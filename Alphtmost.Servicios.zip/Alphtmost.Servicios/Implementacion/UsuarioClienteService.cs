﻿using Alphtmost.Modelos;
using Alphtmost.Servicios.Interfaz;
using AlphtmostAPI.Consumer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alphtmost.Servicios.Implementacion
{
    public class UsuarioClienteService : IUsuarioClienteService
    {
        private readonly ServicioDeVerificacionCorreoCliente _servicioDeVerificacionCorreo;

        public UsuarioClienteService(ServicioDeVerificacionCorreoCliente servicioDeVerificacionCorreo)
        {
            _servicioDeVerificacionCorreo = servicioDeVerificacionCorreo;
        }

        // Método para obtener un usuario por su correo de forma asincrónica
        public async Task<UsuarioCliente> GetByEmailAsync(string email)
        {
            if (string.IsNullOrEmpty(email))
                throw new ArgumentNullException(nameof(email), "El correo no puede ser nulo o vacío.");

            try
            {
                return await Crud<UsuarioCliente>.GetByEmailAsync(email);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al obtener el usuario con el correo {email}: {ex.Message}");
                return null;
            }
        }

        // Método para verificar si el correo electrónico está registrado globalmente
        // Se delega la verificación a ServicioDeVerificacionCorreo
        public async Task<bool> IsEmailRegisteredAsync(string email)
        {
            // Verificamos si el correo está registrado en cualquier servicio usando el servicio de verificación
            return await _servicioDeVerificacionCorreo.IsEmailRegisteredAsync(email);
        }

        // Método para obtener todos los usuarios
        public IEnumerable<UsuarioCliente> GetAllUsuarios()
        {
            try
            {
                // Usamos Crud<UsuarioCliente> para obtener todos los usuarios
                var usuarios = Crud<UsuarioCliente>.GetAll(); // Obtener todos los usuarios
                return usuarios;
            }
            catch (Exception ex)
            {
                // Loguear el error
                Console.WriteLine($"Error al obtener todos los usuarios: {ex.Message}");
                return new List<UsuarioCliente>();  // Devolver una lista vacía si ocurre un error
            }
        }

        // Método para crear un nuevo usuario
        public UsuarioCliente CreateUsuario(UsuarioCliente usuario)
        {
            if (usuario == null)
            {
                throw new ArgumentNullException(nameof(usuario), "El usuario no puede ser nulo");
            }

            try
            {
                // Usamos Crud<UsuarioCliente> para crear un nuevo usuario
                var nuevoUsuario = Crud<UsuarioCliente>.Create(usuario);
                return nuevoUsuario;
            }
            catch (Exception ex)
            {
                // Loguear el error
                Console.WriteLine($"Error al crear el usuario con email {usuario.Email}: {ex.Message}");
                return null; // Devolver null si la creación falla
            }
        }

        // Implementación del método de actualización

        // Método síncrono para actualizar un usuario
        public UsuarioCliente UpdateUsuario(UsuarioCliente usuario)
        {
            if (usuario == null)
                throw new ArgumentNullException(nameof(usuario), "El usuario no puede ser nulo");

            try
            {
                Crud<UsuarioCliente>.Update(usuario.Id, usuario);
                // Si no necesitas recargar desde la base de datos, simplemente retorna el usuario:
                return usuario;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al actualizar el usuario con email {usuario.Email}: {ex.Message}");
                // Puedes lanzar la excepción o retornar null según tu lógica
                throw;
            }
        }
    }
}
