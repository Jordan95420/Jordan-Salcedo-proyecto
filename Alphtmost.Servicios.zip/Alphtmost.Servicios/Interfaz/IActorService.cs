﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphtmost.Servicios.Interfaz
{
    public interface IActorService<TActor>
    {

        Task<TActor> GetByEmailAsync(string email);
        IEnumerable<TActor> GetAll();
        TActor Create(TActor actor);
        TActor Update(TActor actor);
        Task<bool> IsEmailRegisteredAsync(string email);

        // los servicios de IAdministradorService, IArtistaClienteService, IUsuarioClienteService

        //se hara una sola interfaz en lugar de 3 para seguir los diagramas UML de Modelamiento de Software Actualizados que tenemos con el ingeniero
    }
}
