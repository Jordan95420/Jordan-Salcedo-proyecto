﻿using Alphtmost.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphtmost.Servicios.Interfaz
{
    public interface IAdministradorService
    {
        Task<Administrador> GetByEmailAsync(string email);    // Obtener el administrador por correo
        IEnumerable<Administrador> GetAllAdministradores();  // Obtener todos los administradores
        Administrador UpdateAdministrador(Administrador usuario);
    }
}
