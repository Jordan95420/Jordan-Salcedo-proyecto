﻿using Alphtmost.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphtmost.Servicios.Interfaz
{
    public interface IArtistaClienteService
    {
        Task<ArtistaCliente> GetByEmailAsync(string email);  
        IEnumerable<ArtistaCliente> GetAllArtistas();  
        ArtistaCliente CreateArtista(ArtistaCliente artista);  
        Task<bool> IsEmailRegisteredAsync(string email);
        ArtistaCliente UpdateArtista(ArtistaCliente usuario);
    }
}

