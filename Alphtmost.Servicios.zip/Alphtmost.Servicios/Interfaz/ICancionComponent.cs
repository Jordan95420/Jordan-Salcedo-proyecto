﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphtmost.Servicios.Interfaz
{
    public interface ICancionComponent
    {
        Task SubirAsync(IFileUploader uploader);
    }
}
