﻿using Alphtmost.Modelos;
using Alphtmost.Servicios.VistasModelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphtmost.Servicios.Interfaz
{
    public interface IUsuarioClienteService
    {

        Task<UsuarioCliente> GetByEmailAsync(string email);  
        IEnumerable<UsuarioCliente> GetAllUsuarios();  
        UsuarioCliente CreateUsuario(UsuarioCliente usuario);
        Task<bool> IsEmailRegisteredAsync(string email);
        UsuarioCliente UpdateUsuario(UsuarioCliente usuario);
    }

}
