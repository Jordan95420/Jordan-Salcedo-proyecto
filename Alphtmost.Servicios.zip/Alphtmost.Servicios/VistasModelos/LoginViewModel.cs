﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphtmost.Servicios.VistasModelos
{
    public class LoginViewModel
    {
        public string Email { get; set; } // Correo electrónico del usuario
        public string Contraseña { get; set; } // Contraseña del usuario
    }
}
