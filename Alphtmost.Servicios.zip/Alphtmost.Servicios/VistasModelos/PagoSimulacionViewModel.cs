﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphtmost.Servicios.VistasModelos
{
    public class PagoSimulacionViewModel
    {
        [Required]
        public string NombreTitular { get; set; } 

        [Required]
        [CreditCard] 
        public string NumeroTarjeta { get; set; } 

        [Required]
        [RegularExpression(@"^(0[1-9]|1[0-2])\/([0-9]{2})$", ErrorMessage = "Fecha de expiración no válida (MM/AA).")]
        public string FechaExpiracion { get; set; } // Fecha de expiración 

        [Required]
        [StringLength(3, MinimumLength = 3, ErrorMessage = "El código de seguridad debe tener 3 dígitos.")]
        public string CodigoSeguridad { get; set; } // codigo de seguridad (CVV)

        [Required]
        public double Monto { get; set; } // Monto del pago (asociado al tipo de plan premium)

        public string MetodoPago { get; set; } 
        public string EstadoTransaccion { get; set; }
    }

}
